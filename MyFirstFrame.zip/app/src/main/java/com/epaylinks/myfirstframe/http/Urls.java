package com.epaylinks.myfirstframe.http;

/**
 * Created by Administrator on 2016/11/10.
 */

public class Urls {
    public static final String BASEURl="";
}
