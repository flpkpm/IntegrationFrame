package com.epaylinks.myfirstframe.imgeLoader;

/**
 * Created by Administrator on 2016/12/2.
 */

public class ImageLoaderHelper {
    //整整的操纵最外层惊行图片加载的，主要是为了应付以后更加方便的替换新的网络框架
    //只需要一个url,一个imageView  不断的优化属于自己的框架，不断的积累，不断的完善，化化作实际生产，可以封装成jar包 作为成长得一部分




}
